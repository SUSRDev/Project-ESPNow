# -*- coding: utf-8 -*-
from pathlib import Path
import re
t = Path("src/cn_pinyin_data.h").read_text(encoding="utf-8")
words = re.findall(r'  "([^"]+)",', t.split("PY_PHRASE_WORDS")[1].split("PY_PHRASE_KEYS")[0])
Path("tools/_nh_out.txt").write_text(
    "nh=" + ",".join(words[3049:3052]) + "\nnihao=" + words[3052] + "\n",
    encoding="utf-8",
)
